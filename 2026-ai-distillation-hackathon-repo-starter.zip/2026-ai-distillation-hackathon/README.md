# 2026 AI Distillation Hackathon Dataset

古橋研究室の卒論・ゼミ論データを用いて、複数AIの「研究室知識蒸留」性能を比較評価するためのリポジトリです。

## Purpose

このプロジェクトは、研究室に蓄積された卒論・ゼミ論データをAIがどの程度活用し、後輩の研究相談に役立つ回答を生成できるかを評価するものです。

単なるAI比較ではなく、以下を検証します。

- 研究室知識の継承
- 卒論・ゼミ論検索支援
- 後輩向け研究相談AIの実用性
- ハルシネーション抑制
- 推測管理
- 暗黙知の形式知化

## Phase 01

Phase 01では、11問の質問に対する5つのAI回答を比較しました。

評価対象:

- AI 1
- AI 2
- AI 3
- AI 4
- AI 5

AIの正体は、評価バイアスを避けるため匿名化しています。

## Evaluation Criteria

| 評価観点 | 内容 |
|---|---|
| 正確性 | ハルシネーションや矛盾が少ないか |
| 具体性 | 年度・固有名詞・ツール名・研究事例があるか |
| 構造性 | 比較・分類・整理が見やすいか |
| 実用性 | 後輩が次の行動に移せるか |

各項目5点、1問20点。  
11問で合計220点満点です。

## Main Finding

4評価者の平均では、AI 4が最も高評価でした。

| 順位 | AI | 平均点 |
|---:|---|---:|
| 1位 | AI 4 | 196.5 / 220 |
| 2位 | AI 1 | 170.75 / 220 |
| 3位 | AI 2 | 169.5 / 220 |
| 4位 | AI 3 | 167.5 / 220 |
| 5位 | AI 5 | 0 / 220 |

AI 4は、推測を断定しすぎず、質問に忠実で、後輩が次に行動できる形に回答を整理できていた点が強みでした。

## Repository Structure

```text
2026-ai-distillation-hackathon/
├─ README.md
├─ phase_01/
│  ├─ dataset/
│  │  ├─ source_data/
│  │  ├─ questions/
│  │  └─ prompts/
│  ├─ responses/
│  │  ├─ chatgpt/
│  │  ├─ notebooklm/
│  │  └─ ai_studio/
│  ├─ evaluations/
│  └─ analysis/
└─ assets/
   ├─ charts/
   └─ screenshots/
```

## How to Import Data

1. `phase_01/dataset/source_data/` に卒論・ゼミ論リポジトリ一覧を入れる。
2. `phase_01/dataset/questions/` に質問セットを入れる。
3. `phase_01/dataset/prompts/` に採点プロンプトを入れる。
4. `phase_01/responses/` に各AIの回答を入れる。
5. `phase_01/evaluations/` に評価結果を入れる。
6. `phase_01/analysis/` に考察・分析メモを入れる。
