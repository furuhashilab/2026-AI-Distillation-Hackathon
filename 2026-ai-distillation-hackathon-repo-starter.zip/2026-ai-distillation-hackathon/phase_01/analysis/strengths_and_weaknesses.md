# Strengths and Weaknesses

## AI 4

### Strengths

- 4評価者平均で1位
- 推測管理が強い
- 未着手テーマの扱いが慎重
- 実用性が高い
- 後輩への教育的配慮がある

### Weaknesses

- 保守的に見える場面がある
- 回答がやや会話調になることがある

## AI 1

### Strengths

- 具体例が多い
- 初級・中級質問に強い
- 実用的な誘導ができる

### Weaknesses

- 難問で推測管理が弱くなることがある

## AI 2

### Strengths

- 具体性が高い
- 人物名・年度・研究例を出せる

### Weaknesses

- 細部の揺れがある
- 不確実性処理はAI4より弱い

## AI 3

### Strengths

- 構造は整っている
- 数値抽出が強い場面がある

### Weaknesses

- 評価者間のばらつきが大きい
- 質問から外れる場面がある

## AI 5

### Weaknesses

- 無回答
- 全評価者で0点
