# Data Import Manifest

| Category | File Name | Recommended Path | Description |
|---|---|---|---|
| source_data | 古橋研_ゼミ論卒論リポジトリ一覧(1).xlsx | phase_01/dataset/source_data/ | 卒論・ゼミ論リポジトリ一覧 |
| questions | 木曜質問案１.pdf | phase_01/dataset/questions/ | 木曜トーナメント質問セット |
| prompt | scoring_prompt(1).md | phase_01/dataset/prompts/ | 1回目に使った採点プロンプト |
| evaluation | 古橋研_AI回答評価結果.md | phase_01/evaluations/ | 評価結果 |
| evaluation | furuhashi_chatgptresult_ai_evaluation.md | phase_01/evaluations/ | ChatGPT評価結果 |
| response | ai_studio_code_result.txt | phase_01/responses/ai_studio/ | AI Studio出力 |
