# Tomoya Dataset

古橋研究室の卒論・ゼミ論Markdown群をもとに作成した、
研究室知識蒸留用データセット。

## Included Files

- 01_all_research_summaries
- 02_index_keywords
- 03_cross_theme_analysis
- 04_tool_index
- 05_evaluation_questions
- 06_failure_log_and_strategy

## Purpose

- 古橋くんGPT
- NotebookLM
- Custom GPT
- RAG比較
- 研究室知識継承
- 卒論検索支援
